package org.example;

public class Settings {
    //method for toggle sound effects
    Settings(){
        toggleSoundEffects();
        toggleBgMusic();
        chooseTheme();
    }
    public void toggleSoundEffects() {
        // Toggle sound effects
    }
    //method for toggle bg music
    public void toggleBgMusic() {
        // Toggle music
    }
    //method for choose theme
    public void chooseTheme() {
        // Choose theme
    }
}
