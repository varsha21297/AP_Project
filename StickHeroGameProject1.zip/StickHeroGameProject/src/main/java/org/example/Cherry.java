package org.example;

public class Cherry {
    // Properties
    private int points;

    // Constructor
    public Cherry(int _points) {
        this.points = _points;
    }

    // Methods
    // Methods related to the cherry, e.g., collecting, deducting, etc.
}
