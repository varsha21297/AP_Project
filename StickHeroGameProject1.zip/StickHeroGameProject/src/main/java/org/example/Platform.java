package org.example;

public class Platform {
    // Properties
    private int width;
    private int height;

    // Constructor
    public Platform(int _width, int _height) {
        this.width = _width;
        this.height = _height;
    }

    // Methods
    // Methods related to the platform, e.g., checking collisions, rendering, etc.
}
