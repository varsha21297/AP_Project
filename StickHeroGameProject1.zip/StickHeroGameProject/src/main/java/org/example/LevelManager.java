package org.example;

public class LevelManager {

    // Properties
    private int level;

    // Constructor
    public LevelManager(int _level) {
        this.level = _level;
    }

    // Method for managing levels
    public void manageLevel() {
        // Manage the level
    }
    //method for progress
    public void progress() {
        // Progress the level
    }
    //method for restart
    public void restart() {
        // Restart the level
    }

}
